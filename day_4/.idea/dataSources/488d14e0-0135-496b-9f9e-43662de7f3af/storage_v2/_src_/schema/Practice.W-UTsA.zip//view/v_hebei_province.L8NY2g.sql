create definer = jhonchen@`%` view v_hebei_province as
select `city`.`aid` AS `aid`, `city`.`atitle` AS `atitle`, `city`.`pid` AS `pid`
from (`Practice`.`areas` `city`
         left join `Practice`.`areas` `province` on ((`city`.`pid` = `province`.`aid`)))
where (`province`.`atitle` = '河北省');

